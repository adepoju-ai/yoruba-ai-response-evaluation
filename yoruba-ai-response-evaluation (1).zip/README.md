# Yoruba AI Response Evaluation

A beginner-friendly portfolio project demonstrating structured
evaluation of AI-generated Yoruba language responses.

## Project overview

This project demonstrates how a Yoruba language specialist can evaluate
AI outputs for: - Meaning accuracy - Yoruba grammar - Naturalness - Tone
marks and diacritics - Context - Cultural appropriateness - Instruction
following

The dataset contains 30 synthetic portfolio examples covering everyday
Yoruba, translation, children's language, tense/aspect, and written
orthography.

## Dataset

File: `data/yoruba_ai_evaluation_dataset.csv`

Each row contains: - `evaluation_id` - `prompt` - `sample_ai_response` -
Seven evaluation dimensions scored from 1--5 - `overall_score` -
`error_category` - `corrected_response` - `evaluator_note` - `source`

## Scoring

5 = Excellent / fully accurate\
4 = Good / minor issue\
3 = Partially correct / noticeable issue\
2 = Major issue\
1 = Incorrect or unrelated

## Evaluation workflow

1.  Read the user's prompt.
2.  Identify the intended meaning.
3.  Compare the AI response with that meaning.
4.  Check grammar and tense/aspect.
5.  Check naturalness and vocabulary.
6.  Check Yoruba tone marks, underdots, and orthography.
7.  Check context and cultural appropriateness.
8.  Check whether the AI followed the instruction.
9.  Give an overall score.
10. Provide a corrected response and a short evaluator note.

## Quality-control approach

The evaluator separates meaning errors from orthographic issues and
avoids treating every alternative wording as incorrect. Regional or
stylistic uncertainty should be flagged for further linguistic review.

## Project scope

This is an independent learning and portfolio project. The responses are
synthetic examples created for demonstration. No proprietary client data
is included.

## Skills demonstrated

-   Yoruba language evaluation
-   English--Yoruba translation review
-   Linguistic error identification
-   AI response quality assessment
-   Data annotation
-   Structured scoring
-   Written Yoruba orthography review
-   Quality-control thinking

## Future extensions

Possible next versions could add: - Larger datasets - Yoruba
speech/transcription evaluation - Translation evaluation -
Prompt-response pair classification - Inter-rater agreement - JSONL
training/evaluation format - Automated consistency checks
